# BU-dataviz-workshop-2019
Installation instructions and needed files for students at the intro to data visualization in R Data + Narrative session June 6
